// Google Apps Script — agenda compartilhada da Luana Make Studio
const NOME_ABA = 'Reservas';

function getSheet_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sh = ss.getSheetByName(NOME_ABA);
  if (!sh) {
    sh = ss.insertSheet(NOME_ABA);
    sh.appendRow(['Data', 'Horário', 'Nome', 'Serviço', 'Observações', 'Registrado em']);
  }
  return sh;
}

function norm_(v, tipo) {
  if (v instanceof Date) {
    return Utilities.formatDate(v, Session.getScriptTimeZone(), tipo === 'data' ? 'yyyy-MM-dd' : 'HH:mm');
  }
  return String(v).trim();
}

function getBooked_(date) {
  const sh = getSheet_();
  const last = sh.getLastRow();
  if (last < 2) return [];
  const rows = sh.getRange(2, 1, last - 1, 2).getValues();
  return rows.filter(r => norm_(r[0], 'data') === date).map(r => norm_(r[1], 'hora'));
}

function doGet(e) {
  const date = (e.parameter && e.parameter.date) || '';
  return json_({ booked: getBooked_(date) });
}

function doPost(e) {
  const lock = LockService.getScriptLock();
  lock.waitLock(10000);
  try {
    const d = JSON.parse(e.postData.contents);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(d.date) || !/^\d{2}:\d{2}$/.test(d.time)) {
      return json_({ ok: false, error: 'invalid' });
    }
    if (getBooked_(d.date).indexOf(d.time) !== -1) {
      return json_({ ok: false, error: 'taken' });
    }
    const sh = getSheet_();
    const row = sh.getLastRow() + 1;
    sh.getRange(row, 1, 1, 5).setNumberFormat('@'); // grava tudo como texto
    sh.getRange(row, 1, 1, 6).setValues([[d.date, d.time, d.name || '', d.service || '', d.notes || '', new Date()]]);
    return json_({ ok: true });
  } finally {
    lock.releaseLock();
  }
}

function json_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}
